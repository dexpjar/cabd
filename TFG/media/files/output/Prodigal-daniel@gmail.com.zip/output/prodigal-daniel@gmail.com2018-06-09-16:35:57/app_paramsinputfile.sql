-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 06-06-2018 a las 12:48:16
-- Versión del servidor: 5.7.22-0ubuntu0.16.04.1
-- Versión de PHP: 7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `CABD`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `app_paramsinputfile`
--

CREATE TABLE `app_paramsinputfile` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `allowed_format` varchar(100) NOT NULL,
  `option` varchar(10) NOT NULL,
  `info` longtext NOT NULL,
  `app_id` int(11) NOT NULL,
  `file_input` varchar(100) NOT NULL,
  `file_output` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELACIONES PARA LA TABLA `app_paramsinputfile`:
--   `app_id`
--       `app_app` -> `id`
--

--
-- Volcado de datos para la tabla `app_paramsinputfile`
--

INSERT INTO `app_paramsinputfile` (`id`, `name`, `type`, `allowed_format`, `option`, `info`, `app_id`, `file_input`, `file_output`) VALUES
(1, 'Gene Data', 'input', '.fasta', '-i', 'Input file, allowed format .fasta', 1, '', ''),
(2, 'Gene Data', 'input', '.fasta', '-i', 'Input file, allowed format .fasta', 2, '', ''),
(3, 'Output Data', 'output', '.fasta', '-a', 'Output file, allowed format .fasta', 2, '', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `app_paramsinputfile`
--
ALTER TABLE `app_paramsinputfile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `app_paramsinputfile_app_id_80d96a6a_fk_app_app_id` (`app_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `app_paramsinputfile`
--
ALTER TABLE `app_paramsinputfile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `app_paramsinputfile`
--
ALTER TABLE `app_paramsinputfile`
  ADD CONSTRAINT `app_paramsinputfile_app_id_80d96a6a_fk_app_app_id` FOREIGN KEY (`app_id`) REFERENCES `app_app` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
